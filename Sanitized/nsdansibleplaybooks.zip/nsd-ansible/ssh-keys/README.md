# SSH keys (NOT included in this repository)

Generate your own keypairs; never commit private keys.

Two keypairs are used by the architecture:

- `n8n_local_key`  - n8n (Docker container) -> command-center HOST over SSH.
  The public key is trusted in the host's authorized_keys. The private key must be
  readable by the `node` user inside the n8n container (perms `644`, not `600`).
- `ansible_key`    - command-center HOST -> target server(s). Public key provisioned to targets.

Generate:

    ssh-keygen -t ed25519 -f ansible_key    -N ""
    ssh-keygen -t ed25519 -f n8n_local_key  -N ""
