#!/bin/bash
PLAYBOOK=$1
EXTRA_VARS=$2
INVENTORY="/opt/ansible/inventory/hosts.ini"
PLAYBOOK_PATH="/opt/ansible/playbooks/$PLAYBOOK"

if [ ! -f "$PLAYBOOK_PATH" ]; then
    echo "ERROR: Playbook $PLAYBOOK not found at $PLAYBOOK_PATH"
    exit 1
fi

CMD="ansible-playbook -i $INVENTORY $PLAYBOOK_PATH"

if [ -n "$EXTRA_VARS" ]; then
    CMD="$CMD -e '$EXTRA_VARS'"
fi

CMD="$CMD -v"

echo "=========================================="
echo "RUNNING: $CMD"
echo "=========================================="

eval $CMD
EXIT_CODE=$?

echo "=========================================="
echo "EXIT CODE: $EXIT_CODE"
if [ $EXIT_CODE -eq 0 ]; then
    echo "STATUS: SUCCESS"
else
    echo "STATUS: FAILED"
fi
echo "=========================================="

exit $EXIT_CODE
