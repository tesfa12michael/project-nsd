# Fill-in placeholders

Replace every token below before deploying (search the tree for `_HERE`):

| Placeholder            | Where                                                             | Set to |
|------------------------|------------------------------------------------------------------|--------|
| `YOUR_SERVER_IP_HERE`  | `inventory/hosts.ini`, `clients/<c>/inventory.ini`, `group_vars/all.yml` | Target server IP / hostname |
| `YOUR_DOMAIN_HERE`     | `clients/<c>/vars.yml`                                            | App domain (e.g. app.example.com) |
| `YOUR_API_DOMAIN_HERE` | `clients/<c>/vars.yml`, `frontend.env`                           | API domain (split-domain) |
| `YOUR_EMAIL_HERE`      | `clients/<c>/vars.yml`                                            | Let's Encrypt email ("" to skip SSL) |
| `YOUR_DB_PASSWORD_HERE`| `group_vars/all.yml`, `roles/*/defaults/main.yml`, `clients/<c>/vars.yml` | Strong DB password (or Ansible Vault) |
| `ssh-keys/`            | excluded                                                          | Generate your own keypairs (see `ssh-keys/README.md`) |
| `YOUR_TELEGRAM_CHAT_ID`| n8n workflow (Success/Failure Notification nodes)                | Your Telegram chat ID |

`group_vars/all.yml` and `roles/*/defaults/main.yml` values are FALLBACK defaults only —
real deployments are driven by `clients/<client>/vars.yml` (see `clients/example-client/`).
